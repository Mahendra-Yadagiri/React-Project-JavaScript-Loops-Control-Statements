import './App.css';

function App() {
  return (
    <div className="App">

      <h1><u>Loops</u></h1>
      {/* <div>
      <button onClick={()=>{
        let engMarks = 35;
        if(engMarks >= 35){
          console.log(`Student Passed in English`);
        }
      }}>if</button>
      </div> */}

      <div>
      <button onClick={()=>{
        let engMarks = 45;
        while(engMarks >= 20){
          console.log(`while--- ${engMarks}`);
          engMarks --
        }
      }}>While Loop</button>
      <p><b>A while loop executes a block of code as long as the condition is true.
It checks the condition before each iteration.</b></p>
<pre><b>{`let i = 0;
while (i <b 5) {
  console.log(i);
  i++;
`}</b>
</pre>
      </div>
<hr></hr>
      <div>
      <button onClick={()=>{
        let telMarks = 6;
        do{
        console.log(`Student Passed in Telugu`);
        }while(telMarks >= 35)
      }}>Do-While Loop</button>
      <p><b>A do-while loop is similar to a while loop, but it guarantees the block will run at least once, even if the condition is false.</b></p>
      <pre><b>{`let i = 0;
do {
  console.log(i);
  i++;
} while (i < 5);`}</b>
</pre>
      </div>
<hr></hr>
      <div>
      <button onClick={()=>{
        for(let i=100; i<=500;i++){
          console.log(i)

        }
      }}>For Loop</button>
      <p><b>A for loop is used to repeat a block of code a specific number of times.
It has three parts: initialization, condition, and increment/decrement.</b></p>
<pre><b>{`for (let i = 0; i < 5; i++) {
  console.log(i);
}
`}</b></pre>
      </div>
      <hr></hr>

       {/* <button onClick={()=>{
        for(let i=1;i<=100;i++){
          for(let j=1;j<=20;j++){
            console.log(`${i}*${j} = ${i*j}`)
          }
        }
      }}>nested</button>  */}
 
       <div>
      <button onClick={()=>{
        for(let i=1;i<=100;i++){
        if(i===5||i===10||i===15||i===20||i===25||i===30||i===35){
          continue;
        }
       
          for(let j=1;j<=20;j++){
           if( j === 4 || j === 6 || j === 8){
            continue;
           }
           console.log(`${i}*${j} = ${i*j}`);
          }
        }
      }}>Nested Loop</button> 
      <p><b>A nested loop is a loop inside another loop.
The inner loop runs completely for each iteration of the outer loop.</b></p>
      <pre><b>
  {`for (let i = 1; i <= 3; i++) {
  for (let j = 1; j <= 2; j++) {
    console.log("i=\${i}, j=\${j}");
  }
}`}</b>
</pre>


 
      </div>


{/* <button
  onClick={() => {
    for (let i = 1; i <= 100; i++) {
      // skip whole tables (5, 10, 15, 20, ...)
      if (i % 5 === 0) {
        continue;
      }

      for (let j = 1; j <= 20; j++) {
        // skip results divisible by 4, 6, 8
        if ((i * j) % 4 === 0 || (i * j) % 6 === 0 || (i * j) % 8 === 0) {
          continue;
        }

        console.log(`${i} * ${j} = ${i * j}`);
      }
    }
  }}
>
  Tables
</button> */}
<hr></hr>
<h1><u>Control Statements</u></h1>



     <div>
      <button onClick={()=>{
        for(let i=1;i<=100000;i++){
          console.log(i);
          if(i===999){
            break;

          }

        }
      }}>break</button>
      <p><b>The break statement is used to exit a loop immediately, even if the loop condition is still true.
It’s often used when you’ve found what you need and don’t want to continue looping.</b></p>
<pre><b>{`for (let i = 1; i <= 10; i++) {
  if (i === 5) {
    break; // Exit the loop when i = 5
  }
  console.log(i);
}
`}</b></pre>
      </div>
      <hr></hr>

      <div>
      <button onClick={()=>{
        for(let i=1;i<=1000;i++){
          if(i>=100 && i<= 900){
            continue;
          }
          console.log(i)
        }
      }}>continue</button>
      <p><b>The continue statement is used to skip the current iteration of a loop and move to the next one.
It’s useful when you want to ignore specific values without stopping the entire loop.</b></p>
<pre><b>{`for (let i = 1; i <= 10; i++) {
  if (i % 2 === 0) {
    continue; // Skip even numbers
  }
  console.log(i);
}
`}</b></pre>
      </div>
     
    </div>
  );
}

export default App;
